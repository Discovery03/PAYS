# PAYS - Professionals At Your Service
The webiste can be found at http://charanchitte.pythonanywhere.com/pays/
# Details of how to use and access the website

REQUIREMENTS:

Install virtual environment for python 3.8
https://www.geeksforgeeks.org/python-virtual-environment/

install python django in the virtual env using the command 
pip install django(in linux)
https://docs.djangoproject.com/en/1.8/howto/windows/(for windows)

activate the vitual env
unzip the django_auth zip file 

go to the django_auth directory in the terminal

run the commands

python3 manage.py makemigrations

python3 manage.py migrate

python3 manage.py runserver

the server will be opened in http://127.0.0.1:8000/
