from django.core.email import send_mail
import random
from django.conf import settings
